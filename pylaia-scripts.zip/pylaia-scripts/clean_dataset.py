import os
import re
from pathlib import Path

# Complete list of problematic characters
PROBLEMATIC_CHARS = [
    '\xa0',    # Non-breaking space
    '\u200f',  # RIGHT-TO-LEFT-MARK
    '\u200e',  # LEFT-TO-RIGHT-MARK
    '\ufeff',  # ZERO WIDTH NO-BREAK SPACE (BOM)
    '\u200c',  # ZERO WIDTH NON-JOINER
    '\u202c',  # POP DIRECTIONAL FORMATTING
    '\u202a',  # LEFT-TO-RIGHT EMBEDDING
    '\u202b',  # RIGHT-TO-LEFT EMBEDDING
    '\u202d',  # LEFT-TO-RIGHT OVERRIDE
    '\u202e',  # RIGHT-TO-LEFT OVERRIDE
]

def clean_text_content(text):
    """Remove problematic chars and normalize spaces"""
    for char in PROBLEMATIC_CHARS:
        text = text.replace(char, ' ')
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def process_text_file(file_path):
    """Clean individual text file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    cleaned = clean_text_content(content)
    
    if cleaned != content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(cleaned)
        return True
    return False

def verify_syms_consistency(syms_path, dataset_dir):
    """Ensure syms.txt matches cleaned dataset"""
    with open(syms_path, 'r', encoding='utf-8') as f:
        valid_chars = {line.split()[0] for line in f}
    
    missing_chars = set()
    for root, _, files in os.walk(dataset_dir):
        for file in files:
            if file.endswith('.txt'):
                with open(Path(root)/file, 'r', encoding='utf-8') as f:
                    for char in f.read():
                        if char not in valid_chars and char not in ['\n', ' ']:
                            missing_chars.add(char)
    
    if missing_chars:
        print("WARNING: Found characters not in syms.txt:")
        for i, char in enumerate(sorted(missing_chars), 1):
            print(f"{i}. {char!r} (U+{ord(char):04x})")
        return False
    return True

def main():
    dataset_dir = input("Enter dataset directory: ").strip()
    syms_path = Path(dataset_dir)/'syms.txt'
    
    if not os.path.isdir(dataset_dir):
        print("Error: Invalid directory")
        return
    
    # Clean all text files
    modified = 0
    for root, _, files in os.walk(dataset_dir):
        for file in files:
            if file.endswith('.txt') and file != 'syms.txt':
                if process_text_file(Path(root)/file):
                    modified += 1
    
    print(f"\nCleaned {modified} text files")
    
    # Verify consistency
    if verify_syms_consistency(syms_path, dataset_dir):
        print("✓ All characters in dataset are present in syms.txt")
    else:
        print("\nPlease update syms.txt with the missing characters above")

if __name__ == "__main__":
    main()
