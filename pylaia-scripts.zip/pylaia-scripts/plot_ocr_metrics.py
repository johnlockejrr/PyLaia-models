import pandas as pd
import matplotlib.pyplot as plt
import argparse
import sys

def load_and_clean_data(filepath):
    """Load CSV and drop rows with missing metrics."""
    df = pd.read_csv(filepath)
    # Drop rows where training metrics are missing (e.g., epochs > 18 in your data)
    df = df.dropna(subset=['tr_cer', 'tr_wer'])
    return df

def plot_cer_wer(df, output_file=None):
    """Plot CER and WER curves."""
    plt.figure(figsize=(14, 6))
    
    # Plot CER
    plt.subplot(1, 2, 1)
    plt.plot(df['epoch'], df['tr_cer'], 'b-', label='Training CER')
    plt.plot(df['epoch'], df['va_cer'], 'r-', label='Validation CER')
    plt.xlabel('Epoch')
    plt.ylabel('CER')
    plt.title('Character Error Rate (CER)')
    plt.legend()
    plt.grid(True)

    # Plot WER
    plt.subplot(1, 2, 2)
    plt.plot(df['epoch'], df['tr_wer'], 'b--', label='Training WER')
    plt.plot(df['epoch'], df['va_wer'], 'r--', label='Validation WER')
    plt.xlabel('Epoch')
    plt.ylabel('WER')
    plt.title('Word Error Rate (WER)')
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"Plot saved to {output_file}")
    else:
        plt.show()

def main():
    parser = argparse.ArgumentParser(description='Plot OCR training metrics (CER/WER) from CSV.')
    parser.add_argument('csv_file', type=str, help='Path to metrics.csv')
    parser.add_argument('--output', type=str, default=None, help='Output file path (e.g., plot.png)')
    args = parser.parse_args()

    try:
        df = load_and_clean_data(args.csv_file)
        plot_cer_wer(df, args.output)
    except FileNotFoundError:
        print(f"Error: File '{args.csv_file}' not found.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
