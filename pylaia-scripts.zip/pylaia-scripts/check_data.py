import os
import cv2
import numpy as np
from pathlib import Path

def check_image(path):
    try:
        img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            print(f"Corrupt image: {path}")
            return False
        if np.any(np.isnan(img)) or np.any(img > 255):
            print(f"Invalid pixel values: {path}")
            return False
        return True
    except Exception as e:
        print(f"Error reading {path}: {str(e)}")
        return False

def check_txt(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read().strip()
            if not text:
                print(f"Empty text file: {path}")
                return False
            return True
    except Exception as e:
        print(f"Error reading {path}: {str(e)}")
        return False

def verify_dataset(data_dir):
    errors = 0
    for img_path in Path(data_dir).rglob('*.png'):
        txt_path = img_path.with_suffix('.txt')
        if not check_image(img_path):
            errors += 1
        if not check_txt(txt_path):
            errors += 1
    print(f"\nFound {errors} issues in {data_dir}")

verify_dataset('images/train')
