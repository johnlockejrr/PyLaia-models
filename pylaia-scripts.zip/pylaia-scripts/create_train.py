from pathlib import Path
import numpy as np
import cv2
import os
import signal
import sys
import random
import shutil
import glob
import time
#from bidi.algorithm import get_display
import re

# record start time
start = time.time()

signal.signal(signal.SIGINT, lambda x, y: sys.exit(0))

print("[*] Convert text lines to train tokens")
# Create train.txt, val.txt, test.txt files
def create_dataset_file(folder, file_ext='txt'):
    with open(f"{folder}.{file_ext}", "w", encoding='utf-8') as tokens_file:
        for path_txt in glob.iglob(f'images/{folder}/*.txt'):
            with open(path_txt) as file:
                for line in file:
                    line = line.rstrip()
                    image_file = os.path.basename(path_txt)[:-4]
                    line = re.sub(r'\s+', ' ', line)
                    train_line = line.replace("", " ")[1: -1]
                    train_line = train_line.replace("  ", " <space> ")
                    tokens_file.write(f"{folder}/{image_file} {train_line}\n")

for folder in ['train', 'val', 'test']:
    create_dataset_file(folder)

print("[*] Convert text lines to train and making ids file")
# Create [train, val, test]_text.txt and [train, val, test]_ids.txt files
def create_text_file(folder, file_ext='txt'):
    with open(f"{folder}_text.{file_ext}", "w", encoding='utf-8') as text_file:
        for path_txt in glob.iglob(f'images/{folder}/*.txt'):
            with open(path_txt) as file:
                for line in file:
                    line = line.rstrip()
                    image_file = os.path.basename(path_txt)[:-4]
                    text_file.write(f"{folder}/{image_file} {line}\n")
    with open(f"{folder}_ids.{file_ext}", "w", encoding='utf-8') as ids_file:
        for path_txt in glob.iglob(f'images/{folder}/*.txt'):
            with open(path_txt) as file:
                for line in file:
                    line = line.rstrip()
                    image_file = os.path.basename(path_txt)[:-4]
                    ids_file.write(f"{folder}/{image_file}\n")

for folder in ['train', 'val', 'test']:
    create_text_file(folder)

print(f"[*] Making wholetext.txt file")
with open(f"wholetext.txt", "w", encoding='utf-8') as wholetext_file:
    for path_txt in glob.iglob(f'images/**/*.txt', recursive=True):
        with open(path_txt) as file:
            for line in file:
                line = line.rstrip()
                wholetext_file.write(f"{line}\n")

# Create syms.txt
print(f"[*] Making syms.txt file")
with open(f"wholetext.txt", 'r') as wholetext_file_read:
    unique_chars = sorted(set(wholetext_file_read.read()) - {" ", "\n"})

with open(f"syms.txt", "w", encoding='utf-8') as syms_file:
    syms_file.write("<ctc> 0\n")
    for i, char in enumerate(unique_chars):
        syms_file.write(f"{char} {i + 1}\n")
    syms_file.write(f"<unk> {i + 2}\n<space> {i + 3}")

print(f"[*] Making corpus_characters.txt file")
with open(f"corpus_characters.txt", "w", encoding='utf-8') as corpus_file:
    with open(f"wholetext.txt") as file:
        for line in file:
            line = line.rstrip()
            #line = get_display(u'%s' % line, base_dir='R')
            line = re.sub(r'\s+', ' ', line)
            train_line = line.replace("", " ")[1: -1]
            train_line = train_line.replace("   ", " <space> ")
            corpus_file.write(f"{train_line}\n")

print(f"[*] Creating config_dataset.yaml file")

config_content = (
    f"syms: syms.txt\n"
    f"img_dirs: [images/]\n"
    f"tr_txt_table: train.txt\n"
    f"va_txt_table: val.txt\n"
    f"te_txt_table: test.txt\n"
    f"fixed_input_height: 128\n"
    f"statistics_output: statistics.md\n"
    f"common:\n"
    f"  experiment_dirname: train\n"
)

with open(f"config_dataset.yaml", "w", encoding='utf-8') as dataset_file:
    dataset_file.write(config_content)

end = time.time()
execution_time = end - start
minutes, seconds = divmod(execution_time, 60)
print("[*] DONE")
print(f"[+] New PyLaia dataset in .")
print(f"(i) Script execution time: {int(minutes)} minutes and {seconds:.2f} seconds.")
