import os
from datasets import load_dataset
from PIL import Image
from tqdm import tqdm
import time

# Configuration - CHANGED TO HEIGHT
TARGET_HEIGHT = 128  # Now resizing to this height
BASE_DIR = "Catmus_medieval"
MAX_RETRIES = 5
RETRY_DELAY = 30

def resize_image(img, target_height=TARGET_HEIGHT):  # CHANGED FUNCTION
    """Resize image to target height while maintaining aspect ratio"""
    height_percent = (target_height / float(img.size[1]))
    width_size = int((float(img.size[0]) * float(height_percent)))
    return img.resize((width_size, target_height), Image.LANCZOS)  # Now (variable, 128)

def process_split(split_name):
    """Process a dataset split with retry logic"""
    split_dir = os.path.join(BASE_DIR, split_name)
    os.makedirs(split_dir, exist_ok=True)

    for attempt in range(MAX_RETRIES):
        try:
            print(f"Attempt {attempt + 1}/{MAX_RETRIES} for {split_name}...")

            # Load dataset with streaming
            dataset = load_dataset(
                "CATMuS/medieval",
                name="default",
                split=split_name,
                streaming=True
            )

            # Process samples with progress bar
            progress_bar = tqdm(enumerate(dataset), desc=f"Processing {split_name}")
            for idx, example in progress_bar:
                base_filename = f"sample_{idx}"
                image_path = os.path.join(split_dir, f"{base_filename}.png")
                text_path = os.path.join(split_dir, f"{base_filename}.txt")

                if os.path.exists(image_path) and os.path.exists(text_path):
                    continue

                try:
                    # Handle image
                    img = example["im"]
                    if not isinstance(img, Image.Image):
                        img = Image.fromarray(img)

                    # Resize to height=128px - CHANGED THIS LINE
                    resized_img = resize_image(img)
                    
                    # Verify dimensions (optional debug)
                    progress_bar.set_postfix(dimensions=resized_img.size)

                    # Save resized image
                    resized_img.save(image_path, "PNG")

                    # Save text
                    with open(text_path, "w", encoding="utf-8") as f:
                        f.write(example["text"])

                except Exception as e:
                    print(f"Error processing sample {idx}: {str(e)}")
                    continue

            return True

        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {str(e)}")
            if attempt < MAX_RETRIES - 1:
                print(f"Waiting {RETRY_DELAY} seconds before retry...")
                time.sleep(RETRY_DELAY)

    return False

def main():
    os.makedirs(BASE_DIR, exist_ok=True)

    splits = ["train", "validation", "test"]

    for split in splits:
        print(f"\n=== Processing {split} split ===")
        success = process_split(split)

        if not success:
            print(f"\n⚠️ Failed to process {split} after {MAX_RETRIES} attempts")
            print("You can try again later or with a better connection")
        else:
            print(f"✅ Successfully processed {split}")

    print(f"\nAll images resized to height={TARGET_HEIGHT}px")
    print("Processing complete. Check your output directory.")

if __name__ == "__main__":
    main()
